<?php include('header 1.php');?>
<link rel="stylesheet" href="validation/dist/css/bootstrapValidator.css"/>
<!DOCTYPE html>
<html>
<body>
<a href="add theatres.php"><button type="button" class="button">ADD THEATRES !
</button></a>
<a href="add movies.php"><button type="button" class="button">ADD MOVIES !
</button></a>
<a href="add shows.php"><button type="button" class="button">ADD SHOWS !
</button></a>
</body>
<style>
.button {
  background-color: red; 
  border:2 px; 
  border-radius : 10px;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin-right: 30px;}
</style>
</html

